import ij.IJ;
import ij.ImagePlus;
import ij.plugin.PlugIn;
import ij.text.TextWindow;

public class Pratica_1  implements PlugIn {
	public void run(String arg) {		
		//ImagePlus img = IJ.openImage("/home/edson/Área de Trabalho/first_image.jpg");
		ImagePlus img = IJ.getImage();
		
		String[] list = new String[img.getWidth()];
		
		String linha = "";
		
		StringBuffer sb = new StringBuffer();
		
		img.show();
		
		//ImageWindow win = img.getWindow();
		
		for(int x = 0; x < img.getWidth(); x++) {
			for(int y = 0; y < img.getHeight(); y++) {
				//IJ.log(Integer.toString(img.getPixel(x, y)[0]));
				int pixel = img.getPixel(x, y)[0];
				
				if (pixel <= 9)
					linha = linha + Integer.toString(pixel) + "   ";
				else
					if (pixel <= 99)
						linha = linha + Integer.toString(pixel) + "  ";
					else
						linha = linha + Integer.toString(pixel) + " ";
			}
			list[x] = linha;
			linha = "";
			sb.append(list[x]);
			sb.append("\n");
		}
		
		TextWindow tw = new TextWindow("Teste", "", sb.toString(), 300, 400); 
		//tw.append("Edson");
	}
}